<?php 
defined('BASEPATH') OR exit('No direct script allowed');

class Profile extends CI_controller{
	function __Construct(){
		parent ::__Construct();

	}

	public function Index(){
		$content = array (	'title'		=> 'Media Lapang',
							'content'	=> 'pages/Penyewa/Profile',
						);
		$this->load->view('layout/Wrapper',$content);
	}

}
 ?>