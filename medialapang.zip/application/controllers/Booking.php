<?php 
defined('BASEPATH') OR exit('No direct script allowed');

class Booking extends CI_controller{
	function __Construct(){
		parent ::__Construct();

	}

	public function Index(){
		$content = array (	'title'		=> 'Media Lapang',
							'content'	=> 'pages/Booking',
						);
		$this->load->view('layout/Wrapper',$content);
	}

	public function Payment(){
		$content	= array (	'title'		=> 'Payment',
								'content'	=> 'pages/Payment'
							);
		$this->load->array('layout/Wrapper',$content);
	}

}
 ?>