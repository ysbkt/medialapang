<?php 
defined('BASEPATH') OR exit('No direct script allowed');

class Lapangan extends CI_controller{
	function __Construct(){
		parent ::__Construct();

	}

	public function Basket(){
		$content = array (	'title'		=> 'Media Lapang',
							'content'	=> 'pages/Basket',
						);
		$this->load->view('layout/Wrapper',$content);
	}

	public function Futsal(){
		$content = array (	'title'		=> 'Media Lapang',
							'content'	=> 'pages/Futsal',
						);
		$this->load->view('layout/Wrapper',$content);
	}

	public function Badminton(){
		$content = array (	'title'		=> 'Media Lapang',
							'content'	=> 'pages/Badminton',
						);
		$this->load->view('layout/Wrapper',$content);
	}

	public function Overview(){
		$content = array (	'title'		=> 'Media Lapang',
							'content'	=> 'pages/Overview',
						);
		$this->load->view('layout/Wrapper',$content);
	}

}
 ?>