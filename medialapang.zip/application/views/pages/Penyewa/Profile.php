<div id="profile">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="col-md-3">
					<div class="side-profile">
						<div class="row">
							<div class="col-md-6">
								<div class="pull-left">
									<div class="foto-profile">
										<img src="<?php echo base_url() ?>assets/img/foto-profile.jpg" alt="">
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="pull-right">
									<div class="info-profile">
										<h4>Halim Futsal</h4>
										<span>Penyedia Lapangan</span>
									</div>
								</div>
							</div>							
						</div>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium, repellat! Placeat vero, ratione rerum commodi vel neque architecto magni a, id, blanditiis quaerat omnis voluptates labore, illo nobis aperiam ipsa.
					</div>
					<br>
					<div class="side-profile">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum commodi, iusto magnam ad id eum quidem similique. Illo molestiae est, animi iusto. Laborum corrupti, omnis veritatis non autem sunt quaerat.
					</div>
				</div>
				<div class="col-md-9">
					<div class="isi-profile">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi, est aliquid, provident excepturi nam veritatis reprehenderit ratione autem esse repellat ipsum, amet error eligendi, ullam ipsam. Necessitatibus, recusandae dolorem nihil.
					</div>
				</div>
			</div>
		</div>
	</div>
</div>