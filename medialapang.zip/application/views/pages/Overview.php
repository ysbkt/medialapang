<section id="overview">
    <div class="container">
      <div class="row">
        <div class="col-md-12">

            <div class="row">
              <div class="col-md-12">

                <div class="gambar">
                  <img src="<?php echo base_url() ?>assets/img/badminton.jpg" style="width: 100%; max-height: 400px;" class="image-responsive">
                </div>

                <!-- <div class="detail">
                  <div class="col-md-12">
                    <div class="pull-left">
                      <h3><strong>Halim Futsal</strong></h3>
                    </div>
                    <div class="pull-right">
                      <h4><strong>4/5</strong></h4>
                    </div>
                  </div>
                </div> -->

                <div class="container">
                  <div class="page-header">
                      <h1>Halim Futsal<span class="pull-right label label-default rating">4/5</span></h1>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="panel with-nav-tabs">
                        <div class="panel-heading">
                          <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab1primary" data-toggle="tab">Overview</a></li>
                            <li><a href="#tab2primary" data-toggle="tab">Jadwal</a></li>
                            <li><a href="#tab3primary" data-toggle="tab">Review</a></li>
                            <li><a href="#tab4primary" data-toggle="tab">Photo</a></li>
                          </ul>
                        </div>
                        <div class="panel-body">
                          <div class="tab-content">
                            <div class="tab-pane fade in active" id="tab1primary">
                              <div class="col-md-12">
                                <div class="row">
                                  <div class="col-md-4">
                                    <h4>Nomor Telepon</h4>
                                    <p>021 3792 2747</p>
                                    <small>untuk info lebih lanjut</small>
                                  </div>
                                  <div class="col-md-8">
                                    <h4>Harga</h4>
                                    <div class="row">
                                      <div class="col-md-6">
                                        <p><b>Senin - Jumat</b></p>
                                        <p><b>Sabtu</b></p>
                                        <p><b>Minggu</b></p>
                                      </div>
                                      <div class="col-md-6">
                                        <p>Rp. <?php echo number_format('120000',0,',','.') ?></p>
                                        <p>Rp. <?php echo number_format('120000',0,',','.') ?></p>
                                        <p>Rp. <?php echo number_format('120000',0,',','.') ?></p>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <br>
                              </div>
                              <div class="col-md-12">
                                <div class="row">
                                  <div class="col-md-4">
                                    <h4>Jam Buka</h4>
                                    <p>Setiap Hari</p>
                                    <p>07:00 - 23:00</p>
                                  </div>
                                  <div class="col-md-8">
                                    <h4>Alamat</h4>
                                    <div class="row">
                                      <div class="col-md-12">
                                        <p style="text-align: justify;">Jl. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                      </div>
                                      <div class="col-md-12"><br>
                                        <div class="content">
                                          <div class="google-maps">
                                            <?php $alamat = 'Jalan Raya Kebayoran Lama No.19A, RT.10/RW.1, Grogol Selatan, Kebayoran Lama, RT.10/RW.1, Grogol Sel., Kby. Lama, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12220' ?>
                                            <iframe frameborder="0" style="border:0; width: 100%;" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCYPxI5I0NPveZTjw_kzSBHyvP3IRdYZHQ&q=<?php echo str_replace(" ","+",$alamat); ?>" allowfullscreen></iframe>
                                    </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>

                            </div>
                            <div class="tab-pane fade" id="tab2primary">
                              <div class="col-md-12">
                                <table class="table table-bordered" style="width: 100%; color: #3BB0BF;">
                                  <tr>
                                    <th>Jam</th>
                                    <th>Senin</th>
                                    <th>Selasa</th>
                                    <th>Rabu</th>
                                    <th>Kamis</th>
                                    <th>Jumat</th>
                                    <th>Sabtu</th>
                                    <th>Minggu</th>
                                  </tr>
                                  <tr>
                                    <th>08:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>09:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>10:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>11:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>12:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>13:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>14:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>15:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>16:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>17:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>18:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>19:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>20:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>21:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>22:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>23:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                  <tr>
                                    <th>24:00</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  </tr>
                                </table>
                              </div>
                            </div>
                            <div class="tab-pane fade" id="tab3primary">
                              <div class="col-md-12">
                                <span class="heading">User Rating</span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <p>4.1 average based on 254 reviews.</p>
                                <hr style="border:3px solid #f1f1f1">

                                <div class="row">
                                  <div class="side">
                                    <div>5 star</div>
                                  </div>
                                  <div class="middle">
                                    <div class="bar-container">
                                      <div class="bar-5"></div>
                                    </div>
                                  </div>
                                  <div class="side right">
                                    <div>150</div>
                                  </div>
                                  <div class="side">
                                    <div>4 star</div>
                                  </div>
                                  <div class="middle">
                                    <div class="bar-container">
                                      <div class="bar-1"></div>
                                    </div>
                                  </div>
                                  <div class="side right">
                                    <div>63</div>
                                  </div>
                                  <div class="side">
                                    <div>3 star</div>
                                  </div>
                                  <div class="middle">
                                    <div class="bar-container">
                                      <div class="bar-3"></div>
                                    </div>
                                  </div>
                                  <div class="side right">
                                    <div>15</div>
                                  </div>
                                  <div class="side">
                                    <div>2 star</div>
                                  </div>
                                  <div class="middle">
                                    <div class="bar-container">
                                      <div class="bar-2"></div>
                                    </div>
                                  </div>
                                  <div class="side right">
                                    <div>6</div>
                                  </div>
                                  <div class="side">
                                    <div>1 star</div>
                                  </div>
                                  <div class="middle">
                                    <div class="bar-container">
                                      <div class="bar-1"></div>
                                    </div>
                                  </div>
                                  <div class="side right">
                                    <div>20</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="tab-pane fade" id="tab4primary">
                              <div class="container">
                                <div class="row">
                                  <div class="list-group gallery">
                                    <div class="col-sm-4 col-xs-6 col-md-3 col-lg-3">
                                      <a class="thumbnail fancybox" rel="lightbox" href="<?php echo base_url(); ?>assets/img/badminton.jpg" style="width: 100%; height: auto;" >
                                        <img src="<?php echo base_url(); ?>assets/img/badminton.jpg" style="width: 100%; height: auto;">
                                      </a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </section>

  <script type="text/javascript">
    $(document).ready(function(){
    //FANCYBOX
    //https://github.com/fancyapps/fancyBox
    $(".fancybox").fancybox({
        openEffect: "slow",
        closeEffect: "none"
    });
});
  </script>