<section class="register-block">
  <div class="container">
    <div class="container-regist">
      <div class="row">
        <div class="col-md-12">

          <div class="col-md-4 register-sec">
            <h2 class="text-center">Register Now</h2>
            <form class="register-form">
              <div class="form-group">
                <label for="exampleInputName1" class="text-uppercase">Name</label>
                <input type="name" class="form-control" placeholder="">
              </div>
              <div class="form-group">
                <label for="exampleInputAddress1" class="text-uppercase">Address Line 1</label>
                <textarea type="address1" style="max-width: 330px; max-height: 200px;" class="form-control" placeholder=""></textarea>
              </div>
              <div class="form-group">
                <label for="exampleInputTown1" class="text-uppercase">Kecamatan</label>
                <input type="town" class="form-control" placeholder="">
              </div>
              <div class="form-group">
                <label for="exampleInputCountry1" class="text-uppercase">Kotamadya</label>
                <input type="country" class="form-control" placeholder="">
              </div>
              <div class="form-group">
                <label for="exampleInputPostCode1" class="text-uppercase">Kode Pos</label>
                <input type="postcode" class="form-control" placeholder="">
              </div>
              <div class="form-group">
                <label for="exampleInputUsername" class="text-uppercase">Username</label>
                <input type="text" class="form-control" placeholder="">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail" class="text-uppercase">Email</label>
                <input type="email" class="form-control" placeholder="">
              </div>
              <div class="form-group">
                <label for="exampleInputPassword1" class="text-uppercase">Password</label>
                <input type="password" class="form-control" placeholder="">
              </div>
              <div class="form-check">
                <button type="submit" class="btn btn-register float-right btn-block">Daftar</button>
              </div>
            </form>
          </div>

          <div class="col-md-8">
            <div class="banner-sec">
              <img src="<?php echo base_url() ?>assets/img/admin.jpg" style="width: 100%;">
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</section>

<div class="clearfix"></div>