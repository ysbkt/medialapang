<!--==========================
  Footer
============================-->
 <div id="footer" data-animate="fadeInUp">
  <div class="container">
    <div class="row justify-content-start">
      <div class="col-md-12">
        <div class="col-md-2"></div>
        <div class="col-md-4">
          <hr>
          <h4>Get in Touch</h4>
            <div class="row">  
              <div class="col-xs-4" style="text-align: justify;">
                <span><p>Address  :</p></span><br>
                <span><p>Handphone  :</p></span>
                <span><p>Office :</p></span>
                <span><p>Email  :</p></span>
              </div>
              <div class="col-xs-6" style="text-align: justify;">
                <p>Jalan Pinang Ranti 2 Jakarta Timur</p>
                  <p>0878 8504 5227</p>
                  <p>(021) 228 034 16</p>
                  <p>medialapang@gmail.com</p>
              </div>
            </div>
          <hr class="hidden-md hidden-lg">
        </div>

        <div class="col-md-4">
          <hr>
          <h4>Social Media</h4>
          <h5>Cari tahu berbagai berita update seputar lapangan terbaru.</h5>
          <p class="social">
            <a href="#" title="Media Lapang" class="facebook external"><i class="fa fa-facebook"></i></a>
            <a href="#" class="twitter external" title="Media Lapang"><i class="fa fa-twitter"></i></a>
            <a href="#" class="instagram external" title="Media Lapang"><i class="fa fa-instagram"></i></a>
            <a href="#" class="gplus external" title="Media Lapang"><i class="fa fa-google-plus"></i></a>
            <a href="#" class="email external" title="Media Lapang"><i class="fa fa-envelope"></i></a>
          </p>
          <hr class="hidden-md hidden-lg">
          <br>
          <p class="social">
            &copy; 2018 Media Lapang
          </p>
        </div>
        <div class="col-md-2"></div>
      </div>
    </div>
  </div>
</div>
<!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- Required JavaScript Libraries -->
  <script src="<?php echo base_url(); ?>assets/lib/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/lib/superfish/hoverIntent.js"></script>
  <script src="<?php echo base_url(); ?>assets/lib/superfish/superfish.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/lib/morphext/morphext.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/lib/wow/wow.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/lib/stickyjs/sticky.js"></script>
  <script src="<?php echo base_url(); ?>assets/lib/easing/easing.js"></script>


  <!-- Template Specisifc Custom Javascript File -->
  <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>

  <script src="<?php echo base_url(); ?>assets/contactform/contactform.js"></script>

  


</body>

</html>