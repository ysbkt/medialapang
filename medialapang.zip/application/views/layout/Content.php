<?php 

	if ( ! defined('BASEPATH')) exit ('No direct script access allowed');
	if ($content){
		$this->load->view($content);
	}

 ?>
